
Partial Class Change_Password
    Inherits System.Web.UI.Page

End Class

Partial Class CartDetailReport
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'CrystalReportViewer1.ReportSource = "~\rptCartDetail.rpt"
    End Sub
End Class

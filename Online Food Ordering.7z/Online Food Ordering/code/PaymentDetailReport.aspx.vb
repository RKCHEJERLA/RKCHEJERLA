
Partial Class PaymentDetailReport
    Inherits System.Web.UI.Page

End Class


Partial Class ClientDetailReport
    Inherits System.Web.UI.Page

End Class
